# Backend/ai/llama_service.py
import requests
from settings import settings


def query_llama(prompt: str) -> str:
    """
    Unified LLM caller.
    - Supports llama.cpp, ollama (OpenAI-compatible)
    - No hard-coded URL
    """

    if settings.BACKEND == "llama":
        base_url = settings.LLAMA_URL
    elif settings.BACKEND == "ollama":
        base_url = settings.OLLAMA_URL
    else:
        raise ValueError(f"Unsupported BACKEND: {settings.BACKEND}")

    url = base_url + settings.CHAT_COMPLETION_PATH

    payload = {
        "model": settings.MODEL_NAME,
        "messages": [
            {
                "role": "system",
                "content": "You are a strict data analysis planner. Output ONLY valid JSON."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0,
        "top_p": 1,
        "max_tokens": 512
    }

    response = requests.post(url, json=payload, timeout=60)
    response.raise_for_status()

    return response.json()["choices"][0]["message"]["content"].strip()
